CFR 0.152 output from the exact fixed 1.8.1 JAR.
Reference only; not original buildable Forge source.
JAR SHA-256: beeedcd097ebbfc8dc212f34b52d6fd3f6d09504aacced44bfd249aa7a16cf3d
